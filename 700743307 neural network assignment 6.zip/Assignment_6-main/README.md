# Assignment_6
Keras basics
